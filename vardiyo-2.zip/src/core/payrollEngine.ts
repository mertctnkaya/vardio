// src/core/payrollEngine.ts
import type { PayrollResult } from '../types';
import { TAX_CONSTANTS } from '../constants/taxRates';

export const calculatePayroll = (
  baseMonth: number,
  overtime: number,
  nightBonus: number,
  holidayWork: number,
  extra: number,
  extraSgkExempt: boolean,
  absent: number,
  late: number,
  bes: number,
  other: number
): PayrollResult => {
  // 1. Brüt Hakedişleri Topla
  const totalGrossHakedis = baseMonth + overtime + nightBonus + holidayWork + extra;

  // 2. Devamsızlık ve Geç Kalma Kesintilerini Düş (Yeni Brüt Matrah)
  const deductionsGrossTotal = absent + late;
  const newGrossMatrah = Math.max(0, totalGrossHakedis - deductionsGrossTotal);

  // 3. Vergileri Hesapla (70 TL'lik ince ayar mantığı burada korunuyor)
  let sgkMatrah = newGrossMatrah;
  
  // Eğer ek kazanç SGK'dan muafsa (Örn: Yol/Yemek istisnası), SGK matrahından düşürülür
  if (extraSgkExempt && extra > 0) {
    sgkMatrah = Math.max(0, sgkMatrah - extra);
  }

  // SGK İşçi Payı (%14) ve İşsizlik Payı (%1)
  const sgk = sgkMatrah * 0.14;
  const unemployment = sgkMatrah * 0.01;

  // Gelir Vergisi Matrahı (Brüt - SGK - İşsizlik)
  const incomeTaxMatrah = Math.max(0, newGrossMatrah - sgk - unemployment);
  
  // Gelir Vergisi (%15 - 1. Dilim varsayılan)
  const incomeTax = incomeTaxMatrah * TAX_CONSTANTS.INCOME_TAX_TIER_1;
  
  // Damga Vergisi (Binde 7.59 - Yeni Brüt Matrah üzerinden)
  const stampTax = newGrossMatrah * TAX_CONSTANTS.STAMP_TAX_RATE;

  // 4. Net Maaşı Bul
  // Toplam Yasal Kesintiler
  const totalTaxes = sgk + unemployment + incomeTax + stampTax;
  const netBeforeDeductions = newGrossMatrah - totalTaxes;

  // Özel Kesintiler (BES, İcra vb.)
  const totalNetDeductions = bes + other;
  
  // Hesaba Yatan Son Net Para
  const hesabaYatanNet = Math.max(0, netBeforeDeductions - totalNetDeductions);

  return {
    incomes: {
      baseMonth,
      overtime,
      nightBonus,
      holidayWork,
      extra,
      extraSgkExempt,
      totalGrossHakedis
    },
    deductionsGross: {
      absent,
      late
    },
    newGrossMatrah,
    taxes: {
      sgk,
      unemployment,
      incomeTax,
      stampTax
    },
    netKesintiler: {
      bes,
      other
    },
    hesabaYatanNet
  };
};