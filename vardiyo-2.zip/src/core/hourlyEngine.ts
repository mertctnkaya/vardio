// src/core/hourlyEngine.ts
import type { HourlyCalcResult } from '../types';
import { TAX_CONSTANTS } from '../constants/taxRates';

export const calculateHourlyWage = (
  inputValue: string,
  inputType: 'net' | 'gross',
  baseWorkHours: number = 7.5
): HourlyCalcResult | null => {
  const cleanValue = inputValue.replace(/\./g, '').replace(',', '.');
  const val = Number(cleanValue);
  if (!val || val <= 0) return null;

  let monthlyGross = 0;
  let hourlyGross = 0;

  if (inputType === 'gross') {
    hourlyGross = val;
    monthlyGross = hourlyGross * baseWorkHours * 30;
  } else {
    const dailyNet = val * baseWorkHours;
    const monthlyNet = dailyNet * 30;
    
    if (monthlyNet > TAX_CONSTANTS.HOURLY_CALC_NET_LIMIT) {
       monthlyGross = (monthlyNet - TAX_CONSTANTS.HOURLY_CALC_NET_LIMIT) / TAX_CONSTANTS.HOURLY_CALC_COEF_1;
    } else {
       monthlyGross = monthlyNet / TAX_CONSTANTS.HOURLY_CALC_COEF_2; 
    }
    hourlyGross = (monthlyGross / 30) / baseWorkHours;
  }

  const dailyGross = monthlyGross / 30;
  const overtimeGross = hourlyGross * 1.5;

  return {
    monthlyGross: Number(monthlyGross.toFixed(2)),
    dailyGross: Number(dailyGross.toFixed(2)),
    hourlyGross: Number(hourlyGross.toFixed(2)),
    overtimeGross: Number(overtimeGross.toFixed(2))
  };
};