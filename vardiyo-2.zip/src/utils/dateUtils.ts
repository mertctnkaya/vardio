// Tarihi her zaman Türkiye/Lokal saat diliminde yyyy-aa-gg formatında döndürür.
// Gece 00:00 ile 03:00 arasındaki gün kayması bug'ını kalıcı olarak çözer.
export const getLocalDateString = (date: Date): string => {
  const tzOffset = date.getTimezoneOffset() * 60000;
  return new Date(date.getTime() - tzOffset).toISOString().split('T')[0];
};

// "2026-07-28" gibi bir veriyi "Temmuz 2026" yazısına dönüştürür.
export const getFormattedMonthYear = (date: Date): string => {
  return new Intl.DateTimeFormat('tr-TR', { month: 'long', year: 'numeric' }).format(date);
};