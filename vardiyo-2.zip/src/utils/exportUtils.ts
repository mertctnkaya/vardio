// src/utils/exportUtils.ts

// Sadece PDF yazdırma işlemi için sekme adını geçici değiştirir
export const printToPDF = (documentTitle: string) => {
  const originalTitle = document.title;
  document.title = documentTitle;
  window.print();
  document.title = originalTitle;
};

// Genel CSV İndirme Motoru
export const downloadCSV = (filename: string, csvContent: string) => {
  const blob = new Blob([csvContent], { type: 'text/csv;charset=utf-8;' });
  const url = URL.createObjectURL(blob);
  const link = document.createElement("a");
  link.href = url;
  link.setAttribute("download", `${filename}.csv`);
  document.body.appendChild(link);
  link.click();
  document.body.removeChild(link);
};

// Genel JSON İndirme Motoru
export const downloadJSON = <T,>(filename: string, data: T) => {
  const blob = new Blob([JSON.stringify(data, null, 2)], { type: 'application/json' });
  const url = URL.createObjectURL(blob);
  const link = document.createElement("a");
  link.href = url;
  link.setAttribute("download", `${filename}.json`);
  document.body.appendChild(link);
  link.click();
  document.body.removeChild(link);
};

// Dosya isimlendirme formatlayıcısı (Örn: Vardio_Bordro_Temmuz_2026_Mert)
export const getExportFilename = (prefix: string, date: Date, userName: string = 'Rapor') => {
  const dateStr = new Intl.DateTimeFormat('tr-TR', { month: 'long', year: 'numeric' }).format(date).replace(/\s+/g, '_');
  const cleanName = userName.replace(/\s+/g, '_');
  return `Vardio_${prefix}_${dateStr}_${cleanName}`;
};