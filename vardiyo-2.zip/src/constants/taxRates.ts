export const TAX_CONSTANTS = {
  STAMP_TAX_RATE: 0.00759,
  INCOME_TAX_TIER_1: 0.15,
  // Saatlik ücret hesaplamasında kullanılan matematiksel katsayılar
  HOURLY_CALC_NET_LIMIT: 4462.03,
  HOURLY_CALC_COEF_1: 0.71491,
  HOURLY_CALC_COEF_2: 0.85,
};