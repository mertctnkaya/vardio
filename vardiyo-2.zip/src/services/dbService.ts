import { supabase } from '../lib/supabaseClient';
import type { WorkLog } from '../types';

// Belirli bir tarih aralığındaki vardiya kayıtlarını getirir
export const fetchWorkLogs = async (userId: string, startDate: string, endDate: string) => {
  const { data, error } = await supabase
    .from('work_logs')
    .select('date, status, hours, note')
    .eq('user_id', userId)
    .gte('date', startDate)
    .lte('date', endDate);

  if (error) {
    console.error('Work logs fetch error:', error.message);
    return null;
  }
  
  // Gelen veriyi { '2026-07-15': { status: 'holiday_work', ... } } formatına çevir
  const logMap: Record<string, WorkLog> = {};
  if (data) {
    data.forEach(log => {
      logMap[log.date] = {
        status: log.status,
        hours: log.hours,
        note: log.note
      };
    });
  }
  return logMap;
};

// Tek bir günün vardiya kaydını kaydeder veya günceller (Upsert)
export const saveWorkLog = async (
  userId: string, 
  date: string, 
  logData: WorkLog
) => {
  const { error } = await supabase
    .from('work_logs')
    .upsert({
      user_id: userId,
      date: date,
      status: logData.status,
      hours: logData.hours || null,
      note: logData.note || null,
      updated_at: new Date().toISOString()
    }, { onConflict: 'user_id, date' });

  return { error };
};

// Takvimdeki bir kaydı tamamen siler
export const deleteWorkLog = async (userId: string, date: string) => {
  const { error } = await supabase
    .from('work_logs')
    .delete()
    .eq('user_id', userId)
    .eq('date', date);

  return { error };
};